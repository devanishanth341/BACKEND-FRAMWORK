package com.examly.springapp.repository;

public class CommentRepo {
    
}
