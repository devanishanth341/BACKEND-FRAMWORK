package com.examly.springapp.repository;

import org.springframework.stereotype.Repository;

@Repository
public class TicketRepo {
    
}
